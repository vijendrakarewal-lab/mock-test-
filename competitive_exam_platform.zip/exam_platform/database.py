import sqlite3

DB_PATH = "exam_platform.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    db = get_db()
    db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'student',
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS exams (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            subject TEXT NOT NULL,
            duration INTEGER NOT NULL,
            num_questions INTEGER NOT NULL,
            difficulty TEXT DEFAULT 'hard',
            questions_json TEXT NOT NULL,
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS attempts (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            exam_id TEXT NOT NULL,
            score INTEGER DEFAULT 0,
            total INTEGER DEFAULT 0,
            answers_json TEXT DEFAULT '{}',
            time_taken INTEGER DEFAULT 0,
            completed INTEGER DEFAULT 0,
            submitted_at TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(exam_id) REFERENCES exams(id)
        );
    """)

    # Create default admin if not exists
    import hashlib, uuid
    admin_id = str(uuid.uuid4())
    admin_pw = hashlib.sha256("admin123".encode()).hexdigest()
    db.execute("""
        INSERT OR IGNORE INTO users (id, username, email, password, role)
        VALUES (?, 'admin', 'admin@examplatform.com', ?, 'admin')
    """, (admin_id, admin_pw))
    db.commit()
    db.close()
    print("✅ Database initialized. Admin: admin / admin123")
