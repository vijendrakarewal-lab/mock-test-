"""
AI Question Generator — powered by Claude (Anthropic API)
Generates fresh, high-quality, competitive-exam-level MCQs on demand.
Never uses PYQs; questions are always unique and difficult.
"""

import json, os, random
import anthropic

# ---------------------------------------------------------------------------
# Anthropic client  (set ANTHROPIC_API_KEY in your environment)
# ---------------------------------------------------------------------------
client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", "YOUR_API_KEY_HERE"))

SUBJECT_CONTEXT = {
    "Mathematics": "advanced competitive math (calculus, linear algebra, number theory, combinatorics, probability)",
    "Physics":     "advanced competitive physics (mechanics, electromagnetism, thermodynamics, modern physics, optics)",
    "Chemistry":   "advanced competitive chemistry (organic reactions, inorganic chemistry, physical chemistry, electrochemistry)",
    "Biology":     "advanced competitive biology (genetics, biochemistry, cell biology, ecology, evolution)",
    "Computer Science": "advanced CS concepts (data structures, algorithms, OS, DBMS, networks, theory of computation)",
    "General Knowledge": "current affairs 2024-2025, science & tech, economy, polity, environment (NOT old GK)",
    "Aptitude":    "advanced quantitative aptitude, logical reasoning, data interpretation for competitive exams",
    "English":     "advanced English grammar, vocabulary, reading comprehension, verbal reasoning",
}


def generate_questions_for_exam(subject: str, difficulty: str, count: int) -> list[dict]:
    """
    Calls Claude to generate `count` fresh MCQs for the given subject.
    Returns a list of question dicts:
      { "question": str, "options": [A,B,C,D], "answer": str, "explanation": str }
    """
    subject_hint = SUBJECT_CONTEXT.get(subject, subject)
    diff_label   = difficulty.capitalize()

    prompt = f"""You are an expert question-setter for top competitive exams (like UPSC, JEE Advanced, GATE, CAT, GRE).

Generate exactly {count} UNIQUE, ORIGINAL multiple-choice questions on: **{subject_hint}**
Difficulty level: **{diff_label}** (make them genuinely challenging — avoid trivial or textbook facts)

STRICT RULES:
- Questions MUST be original — do NOT copy from previous year papers (PYQs).
- Each question must test deep conceptual understanding, application, or analysis — NOT memorisation.
- For {diff_label} difficulty, include tricky distractors that look plausible.
- Cover diverse sub-topics within {subject}.
- Date-sensitive GK must be from 2024 or 2025.

Return ONLY a valid JSON array (no markdown, no extra text):
[
  {{
    "question": "<full question text>",
    "options": ["<option A>", "<option B>", "<option C>", "<option D>"],
    "answer": "<exact text of the correct option>",
    "explanation": "<brief explanation why the answer is correct>"
  }},
  ...
]
"""

    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=4096,
        messages=[{"role": "user", "content": prompt}]
    )

    raw = message.content[0].text.strip()

    # Strip markdown fences if present
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    raw = raw.strip()

    questions = json.loads(raw)

    # Safety: ensure we got enough questions
    if len(questions) < count:
        raise ValueError(f"AI returned only {len(questions)} questions (expected {count})")

    return questions[:count]


# ---------------------------------------------------------------------------
# Fallback: hand-crafted sample questions (used only if API key is missing)
# ---------------------------------------------------------------------------

SAMPLE_QUESTIONS = {
    "Mathematics": [
        {
            "question": "If f(x) = x³ - 6x² + 11x - 6, which of the following is NOT a root of f(x)?",
            "options": ["1", "2", "3", "4"],
            "answer": "4",
            "explanation": "f(x) factors as (x-1)(x-2)(x-3), so roots are 1, 2, 3. f(4) = 64-96+44-6 = 6 ≠ 0."
        },
        {
            "question": "The number of ways to arrange 5 distinct books on a shelf such that 2 specific books are never adjacent is:",
            "options": ["48", "72", "96", "120"],
            "answer": "72",
            "explanation": "Total arrangements = 5! = 120. Arrangements where the 2 books ARE adjacent = 4! × 2 = 48. So non-adjacent = 120 - 48 = 72."
        },
        {
            "question": "∫₀^π x·sin(x) dx equals:",
            "options": ["0", "π", "2π", "-π"],
            "answer": "π",
            "explanation": "Using integration by parts: ∫x·sin(x)dx = -x·cos(x) + sin(x) + C. Evaluating from 0 to π: (-π·cos π + sin π) - 0 = π."
        },
    ],
    "Computer Science": [
        {
            "question": "Which of the following sorting algorithms has the best worst-case time complexity?",
            "options": ["Quick Sort — O(n²)", "Merge Sort — O(n log n)", "Heap Sort — O(n log n)", "Both B and C"],
            "answer": "Both B and C",
            "explanation": "Both Merge Sort and Heap Sort guarantee O(n log n) in the worst case, unlike Quick Sort which degrades to O(n²)."
        },
        {
            "question": "In a B-tree of order m, the maximum number of keys in any node is:",
            "options": ["m", "m-1", "2m-1", "⌈m/2⌉-1"],
            "answer": "m-1",
            "explanation": "A B-tree node of order m can hold at most m children and m-1 keys."
        },
        {
            "question": "Which normal form eliminates transitive dependencies?",
            "options": ["1NF", "2NF", "3NF", "BCNF"],
            "answer": "3NF",
            "explanation": "3NF requires that no non-prime attribute is transitively dependent on any candidate key."
        },
    ],
}


def get_sample_questions(subject: str, count: int) -> list[dict]:
    pool = SAMPLE_QUESTIONS.get(subject, SAMPLE_QUESTIONS["Mathematics"])
    # Cycle through if count > pool size
    result = []
    while len(result) < count:
        result.extend(pool)
    random.shuffle(result)
    return result[:count]
