# ⚡ CompetitiveEdge — AI-Powered Online Exam Platform

A full-featured competitive exam platform built with **FastAPI** + **Claude AI**.  
All questions are generated fresh by Claude — zero PYQs, always current (2024-2025).

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Set your Anthropic API key
```bash
# Linux / macOS
export ANTHROPIC_API_KEY="sk-ant-..."

# Windows PowerShell
$env:ANTHROPIC_API_KEY="sk-ant-..."
```

### 3. Run the server
```bash
cd exam_platform
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### 4. Open in browser
```
http://localhost:8000
```

---

## 🔑 Default Admin Credentials
| Username | Password |
|----------|----------|
| `admin`  | `admin123` |

> ⚠️ Change this in `database.py` before deploying to production!

---

## 🌟 Features

| Feature | Details |
|---------|---------|
| 🤖 AI Questions | Claude generates unique, hard MCQs on demand — never PYQs |
| ⏱️ Live Timer | Countdown timer with colour warning, auto-submits on expiry |
| 🏆 Leaderboard | Ranked by accuracy %, then by time taken |
| ⚙️ Admin Panel | Create/delete exams, choose subject, difficulty, question count |
| 📊 Result Review | Full answer breakdown with explanations for every question |
| 🔐 Auth | Register/login with hashed passwords |

---

## 📁 Project Structure
```
exam_platform/
├── main.py            # FastAPI routes
├── database.py        # SQLite setup
├── ai_questions.py    # Claude AI question generator
├── requirements.txt
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── exam.html      # Timed exam interface
│   ├── result.html    # Score + review
│   ├── leaderboard.html
│   └── admin.html
└── static/            # CSS / JS assets
```

---

## 🛡️ Production Tips
- Replace SQLite with PostgreSQL for scale
- Add JWT tokens instead of cookie-based auth
- Rate-limit the `/admin/create-exam` endpoint
- Host on Railway, Render, or AWS with `uvicorn main:app --host 0.0.0.0 --port 8000`
