from fastapi import FastAPI, Request, Depends, HTTPException, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
import sqlite3, hashlib, json, time, uuid
from datetime import datetime
from database import init_db, get_db
from ai_questions import generate_questions_for_exam

app = FastAPI(title="CompetitiveEdge - Online Exam Platform")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# ─── Startup ─────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    init_db()

# ─── Helper ──────────────────────────────────────────────────────────────────

def hash_pw(pw: str) -> str:
    return hashlib.sha256(pw.encode()).hexdigest()

def get_session_user(request: Request):
    return request.cookies.get("user_id")

# ─── Home ─────────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    user_id = get_session_user(request)
    db = get_db()
    exams = db.execute("SELECT * FROM exams ORDER BY created_at DESC").fetchall()
    user = None
    if user_id:
        user = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    db.close()
    return templates.TemplateResponse("index.html", {"request": request, "exams": exams, "user": user})

# ─── Auth ─────────────────────────────────────────────────────────────────────

@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.post("/register")
async def register(request: Request, username: str = Form(...), email: str = Form(...), password: str = Form(...)):
    db = get_db()
    existing = db.execute("SELECT id FROM users WHERE username=? OR email=?", (username, email)).fetchone()
    if existing:
        db.close()
        return templates.TemplateResponse("register.html", {"request": request, "error": "Username or email already exists."})
    uid = str(uuid.uuid4())
    db.execute("INSERT INTO users (id,username,email,password,role) VALUES (?,?,?,?,?)",
               (uid, username, email, hash_pw(password), "student"))
    db.commit(); db.close()
    resp = RedirectResponse("/", status_code=302)
    resp.set_cookie("user_id", uid)
    return resp

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
async def login(request: Request, username: str = Form(...), password: str = Form(...)):
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE username=? AND password=?", (username, hash_pw(password))).fetchone()
    db.close()
    if not user:
        return templates.TemplateResponse("login.html", {"request": request, "error": "Invalid credentials."})
    resp = RedirectResponse("/", status_code=302)
    resp.set_cookie("user_id", user["id"])
    return resp

@app.get("/logout")
async def logout():
    resp = RedirectResponse("/", status_code=302)
    resp.delete_cookie("user_id")
    return resp

# ─── Exam ─────────────────────────────────────────────────────────────────────

@app.get("/exam/{exam_id}", response_class=HTMLResponse)
async def exam_page(request: Request, exam_id: str):
    user_id = get_session_user(request)
    if not user_id:
        return RedirectResponse("/login")
    db = get_db()
    exam = db.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
    if not exam:
        raise HTTPException(404, "Exam not found")
    # Check if already attempted
    attempt = db.execute("SELECT * FROM attempts WHERE user_id=? AND exam_id=? AND completed=1", (user_id, exam_id)).fetchone()
    questions = json.loads(exam["questions_json"])
    db.close()
    return templates.TemplateResponse("exam.html", {
        "request": request, "exam": exam, "questions": questions,
        "attempt": attempt, "enumerate": enumerate
    })

@app.post("/exam/{exam_id}/submit")
async def submit_exam(request: Request, exam_id: str):
    user_id = get_session_user(request)
    if not user_id:
        return RedirectResponse("/login")
    form = await request.form()
    db = get_db()
    exam = db.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
    questions = json.loads(exam["questions_json"])

    score = 0
    total = len(questions)
    answers = {}
    for i, q in enumerate(questions):
        selected = form.get(f"q{i}")
        answers[str(i)] = selected
        if selected and selected == q["answer"]:
            score += 1

    # Save attempt
    attempt_id = str(uuid.uuid4())
    time_taken = form.get("time_taken", 0)
    db.execute(
        "INSERT OR REPLACE INTO attempts (id,user_id,exam_id,score,total,answers_json,time_taken,completed,submitted_at) VALUES (?,?,?,?,?,?,?,1,?)",
        (attempt_id, user_id, exam_id, score, total, json.dumps(answers), time_taken, datetime.now().isoformat())
    )
    db.commit(); db.close()
    return RedirectResponse(f"/result/{attempt_id}", status_code=302)

@app.get("/result/{attempt_id}", response_class=HTMLResponse)
async def result_page(request: Request, attempt_id: str):
    user_id = get_session_user(request)
    db = get_db()
    attempt = db.execute("SELECT * FROM attempts WHERE id=?", (attempt_id,)).fetchone()
    exam = db.execute("SELECT * FROM exams WHERE id=?", (attempt["exam_id"],)).fetchone()
    user = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    questions = json.loads(exam["questions_json"])
    answers = json.loads(attempt["answers_json"])
    db.close()
    return templates.TemplateResponse("result.html", {
        "request": request, "attempt": attempt, "exam": exam,
        "questions": questions, "answers": answers, "user": user, "enumerate": enumerate
    })

# ─── Leaderboard ──────────────────────────────────────────────────────────────

@app.get("/leaderboard", response_class=HTMLResponse)
async def leaderboard(request: Request):
    user_id = get_session_user(request)
    db = get_db()
    rows = db.execute("""
        SELECT u.username, e.title as exam_title,
               a.score, a.total, a.time_taken, a.submitted_at,
               ROUND(a.score * 100.0 / a.total, 1) as percent
        FROM attempts a
        JOIN users u ON u.id = a.user_id
        JOIN exams e ON e.id = a.exam_id
        WHERE a.completed = 1
        ORDER BY percent DESC, a.time_taken ASC
        LIMIT 50
    """).fetchall()
    user = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone() if user_id else None
    db.close()
    return templates.TemplateResponse("leaderboard.html", {"request": request, "rows": rows, "user": user, "enumerate": enumerate})

# ─── Admin ────────────────────────────────────────────────────────────────────

@app.get("/admin", response_class=HTMLResponse)
async def admin_panel(request: Request):
    user_id = get_session_user(request)
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone() if user_id else None
    if not user or user["role"] != "admin":
        db.close()
        return RedirectResponse("/")
    exams = db.execute("SELECT * FROM exams ORDER BY created_at DESC").fetchall()
    db.close()
    return templates.TemplateResponse("admin.html", {"request": request, "user": user, "exams": exams})

@app.post("/admin/create-exam")
async def create_exam(request: Request,
                       title: str = Form(...),
                       subject: str = Form(...),
                       duration: int = Form(...),
                       num_questions: int = Form(...),
                       difficulty: str = Form(...)):
    user_id = get_session_user(request)
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone() if user_id else None
    if not user or user["role"] != "admin":
        db.close(); return RedirectResponse("/")

    # Generate AI questions
    questions = generate_questions_for_exam(subject, difficulty, num_questions)

    eid = str(uuid.uuid4())
    db.execute(
        "INSERT INTO exams (id,title,subject,duration,num_questions,difficulty,questions_json,created_at) VALUES (?,?,?,?,?,?,?,?)",
        (eid, title, subject, duration, num_questions, difficulty, json.dumps(questions), datetime.now().isoformat())
    )
    db.commit(); db.close()
    return RedirectResponse("/admin", status_code=302)

@app.get("/admin/delete-exam/{exam_id}")
async def delete_exam(request: Request, exam_id: str):
    user_id = get_session_user(request)
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone() if user_id else None
    if not user or user["role"] != "admin":
        db.close(); return RedirectResponse("/")
    db.execute("DELETE FROM exams WHERE id=?", (exam_id,))
    db.execute("DELETE FROM attempts WHERE exam_id=?", (exam_id,))
    db.commit(); db.close()
    return RedirectResponse("/admin", status_code=302)
